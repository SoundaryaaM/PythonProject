from django.shortcuts import render,redirect
from django.contrib.auth.models import auth
from homeapp.models import finalp
import psycopg2,os
import pandas as pd
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
from bokeh.plotting import figure, output_file
from bokeh.models import HoverTool, ColumnDataSource
def homepage(request): 
    if request.method=="POST":
        username=request.POST['uname']
        password=request.POST['passw_']
        user=auth.authenticate(username=username,password=password)
        #if username and password is wrong it returns None
        if user is not None:
            auth.login(request, user)
            result=finalp.objects.all()
            os.system("cmd/c'project1.5.py'")
            return render(request,'login.html',{'result':result})
        else:
            return redirect("home")
    else:
        write_details()
        return render(request,'index.html')
def loginpage(request):
    result=finalp.objects.all()
    os.system("pip")
    return render(request,'login.html',{'result':result})

def logoutpage(request):
    auth.logout(request)
    return redirect("home")
def write_details():
    con=psycopg2.connect(database= 'CCTVDB',user='postgres',password='Pass@123',host= 'localhost')
    cur=con.cursor()
    cur.execute("DELETE FROM homeapp_finalp")
    con.commit()
    files=os.listdir(BASE_DIR+"\\media")
    for i in files:
        cur.execute(""" INSERT INTO homeapp_finalp (name,data) VALUES(%s,%s)""",(i,i))
        con.commit()
    cur.close()
    con.close()
def viewdetail(request):
    df=pd.read_csv(BASE_DIR+"\\Times.csv")
    s1=df['Start']
    s2=df['End']
    print(df,s2,s1)
    return render(request,'ViewDetail.html',{"res":zip(s1,s2)})
    
